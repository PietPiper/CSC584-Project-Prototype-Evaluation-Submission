# Rah

## Contributors

Logan Blake

Alex Harvey

Andres Ayala-Lagunas

## Controls

__W__ - Up

__A__ - Left

__S__ - Down

__D__ - Right

__Space__ - Jump

__Shift__ - Dash

__Left Mouse Button__ - Attack

# Development

## The Development Scene

Each developer should have a dedicated scene for development named "development.tscn" in the scenes directory. This scene is ignored when pushing to GitHub so that you may do whatever you like in it without interfering with the other portions of the game that may already be complete.

Any features added into the game should be tested in the development scene before being added elsewhere. This includes monsters, obstacles, interactables, etc.

For established features that affect the game gobally, such as the player controls or enemy decision making, please be sure to thoroughly test these changes before putting it into a pull request and ensure the change works in all cases established in the game. For example, if you must edit the enemy AI, be sure to test it in every scene that enemy is in.

# File System

Please organize any files into their appropriate folders.

The assets folder should contain music, sprites, animations, tile maps, and other files related to the look and feel of our game, further divided into more folders for each type of asset used. The player has a dedicated folder in the assets folder.

The scenes folder should contain scenes of all types, whether it be levels, enemies, or other scenes for components that we deem necessary. They should be further subdivided into categories based on the role of the scene, such as whether it is a level or an enemy.

The scripts folder should contain any code used in the game, further subdivided into categories based on what they do or what they are related to, such as scripts related to enemies or to level design. The player has a deidcated folder in the scripts folder.

## Git Guidelines

### Branches

Work should be done in branches and merged into the main branch via pull requests after review done by the other developers.

Branches should be sorted by Unity ID to clarify who is working in what branch.

To create a branch, use the following command. Make sure you are in the main branch and have pulled the latest changes before doing this.

```bash
git checkout -b <unityid>
```

If you would like to use more descriptive names for your branches (such as if you are working on multiple features at the same time), you should do so as follows:

```bash
git checkout -b <unityid>/<descriptive_name>
```

After creating a branch, and for any already created branch, you can enter it by using the following command.

```bash
git checkout <branch_name>
```

When you first create a branch in this way, it only exists locally. The first time you push changes to a new branch made this way, use the following command.

```bash
git push -u origin <branch_name>
```

Subsequent pushes can be done using the standalone command.

Pushing directly to the main branch is blocked. If you try to, you will receive an error telling you so. If for some reason you cannot push your changes, this may be why, so be sure to double check what branch you are working on when developing and making commits.


### Commits

Commit messages should be descriptive, but concise. To make a commit with a messages, use the following command:

```bash
git commit -m "<message>"
```

If your changes are large, you may consider adding a description to your pull request in order to help reviewers understand them, although is not strictly necessary.
